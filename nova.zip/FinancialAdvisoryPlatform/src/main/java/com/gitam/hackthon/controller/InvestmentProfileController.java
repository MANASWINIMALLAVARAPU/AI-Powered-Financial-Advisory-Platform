package com.gitam.hackthon.controller;

import java.io.ByteArrayInputStream;
import java.io.IOException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import com.gitam.hackthon.model.InvestmentProfile;
import com.gitam.hackthon.repository.InvestmentProfileRepository;
import com.gitam.hackthon.service.GeminiService;

@Controller
public class InvestmentProfileController {

    @Autowired
    private InvestmentProfileRepository investmentProfileRepository;

    @Autowired
    private GeminiService geminiService;  // Add this to use Gemini API

    @GetMapping("/investmentForm")
    public String showInvestmentForm() {
        return "investmentForm"; // Shows the form page
    }

    @PostMapping("/saveInvestment")
    public String saveInvestment(@ModelAttribute InvestmentProfile investment, Model model) {
        investmentProfileRepository.save(investment);
        model.addAttribute("investment", investment);
        return "investmentResult"; // Redirect to result page
    }

    @GetMapping("/")
    public String home() {
        return "index";  // This will return views/index.jsp
    }

    // ✅ New API for Getting Investment Advice using Gemini API
    @PostMapping("/getInvestmentAdvice")
    public String getInvestmentAdvice(@ModelAttribute InvestmentProfile profile, Model model) {
        String investmentAdvice = geminiService.getInvestmentAdvice(profile);
        model.addAttribute("investmentAdvice", investmentAdvice);
        return "investment-advice"; // This maps to the JSP page
    }

    @GetMapping("/downloadReport")
    public ResponseEntity<InputStreamResource> downloadReport(@RequestParam("investmentId") Long investmentId) throws IOException {
        InvestmentProfile investment = investmentProfileRepository.findById(investmentId)
                .orElseThrow(() -> new IOException("Investment not found"));

        String reportContent = generateReport(investment);
        ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(reportContent.getBytes());

        HttpHeaders headers = new HttpHeaders();
        headers.add("Content-Disposition", "attachment; filename=investment_report.txt");

        return ResponseEntity.ok()
                .headers(headers)
                .contentType(MediaType.APPLICATION_OCTET_STREAM)
                .body(new InputStreamResource(byteArrayInputStream));
    }

    private String generateReport(InvestmentProfile investment) {
        StringBuilder report = new StringBuilder();
        report.append("Investment Report\n\n");
        report.append("Email: ").append(investment.getUserEmail()).append("\n");
        report.append("Income: ₹").append(investment.getIncome()).append("\n");
        report.append("Age: ").append(investment.getAge()).append(" years\n");
        report.append("Savings: ₹").append(investment.getSavings()).append("\n");
        report.append("Existing Investments: ").append(investment.getExistingInvestments()).append("\n");
        report.append("Financial Goal: ").append(investment.getFinancialGoal()).append("\n");
        report.append("Investment Goal: ").append(investment.getInvestmentGoal()).append("\n");
        report.append("Has Debt: ").append(investment.getHasDebt() ? "Yes" : "No").append("\n");
        report.append("Risk Level: ").append(investment.getRiskLevel()).append("\n");
        report.append("Investment Type: ").append(investment.getInvestmentType()).append("\n");

        return report.toString();
    }
}
