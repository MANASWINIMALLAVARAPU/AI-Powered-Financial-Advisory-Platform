package com.gitam.hackthon.model;

import jakarta.persistence.*;

@Entity
@Table(name = "user_table")
public class User 
{
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "user_id")
    private int id;
    
    @Column(name = "user_name", nullable = false, unique = true, length = 50)
    private String username;
    
    @Column(name = "user_email", nullable = false, unique = true, length = 50)
    private String email;
    
    @Column(name = "user_password", nullable = false, length = 50)
    private String password;
    
    @Column(name = "user_phone", nullable = false, unique = true, length = 20)
    private String phone;
    
    @Column(name = "user_dob", nullable = false, length = 20)
    private String dob;
    
    @Column(name = "user_gender", nullable = false, length = 20)
    private String gender;
    
    @Column(name = "user_address", nullable = false, length = 100)
    private String address;
    
    @Column(name = "user_income", nullable = false)
    private Double income;
    
    @Column(name = "user_risk_tolerance", nullable = false, length = 50)
    private String riskTolerance;
    
    public int getId() {
        return id;
    }
    
    public void setId(int id) {
        this.id = id;
    }
    
    public String getUsername() {
        return username;
    }
    
    public void setUsername(String username) {
        this.username = username;
    }
    
    public String getEmail() {
        return email;
    }
    
    public void setEmail(String email) {
        this.email = email;
    }
    
    public String getPassword() {
        return password;
    }
    
    public void setPassword(String password) {
        this.password = password;
    }
    
    public String getPhone() {
        return phone;
    }
    
    public void setPhone(String phone) {
        this.phone = phone;
    }
    
    public String getDob() {
        return dob;
    }
    
    public void setDob(String dob) {
        this.dob = dob;
    }
    
    public String getGender() {
        return gender;
    }
    
    public void setGender(String gender) {
        this.gender = gender;
    }
    
    public String getAddress() {
        return address;
    }
    
    public void setAddress(String address) {
        this.address = address;
    }
    
    public Double getIncome() {
        return income;
    }
    
    public void setIncome(Double income) {
        this.income = income;
    }
    
    public String getRiskTolerance() {
        return riskTolerance;
    }
    
    public void setRiskTolerance(String riskTolerance) {
        this.riskTolerance = riskTolerance;
    }
}
