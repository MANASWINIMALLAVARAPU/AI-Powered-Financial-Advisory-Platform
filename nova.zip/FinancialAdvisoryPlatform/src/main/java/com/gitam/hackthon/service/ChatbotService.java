package com.gitam.hackthon.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.hc.client5.http.classic.methods.HttpPost;
import org.apache.hc.client5.http.impl.classic.CloseableHttpClient;
import org.apache.hc.client5.http.impl.classic.CloseableHttpResponse;
import org.apache.hc.client5.http.impl.classic.HttpClients;
import org.apache.hc.core5.http.io.entity.StringEntity;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;

@Service
public class ChatbotService {

    private static final Logger logger = LoggerFactory.getLogger(ChatbotService.class);
    private static final String API_KEY = "AIzaSyAYwIm6CdnJYMx0ft5sZd_0--STBLinSIo"; // Replace with your actual API key
    private static final String API_URL = "https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-pro-latest:generateContent?key=" + API_KEY;



    public String getChatResponse(String userMessage) {
        try (CloseableHttpClient client = HttpClients.createDefault()) {
            HttpPost request = new HttpPost(API_URL);
            request.addHeader("Content-Type", "application/json");

            // Format request body
            String jsonBody = "{ \"contents\": [{ \"parts\": [{ \"text\": \"" + userMessage + "\" }] }] }";
            request.setEntity(new StringEntity(jsonBody, StandardCharsets.UTF_8));

            try (CloseableHttpResponse response = client.execute(request);
                 BufferedReader reader = new BufferedReader(new InputStreamReader(response.getEntity().getContent(), StandardCharsets.UTF_8))) {

                StringBuilder responseString = new StringBuilder();
                String line;
                while ((line = reader.readLine()) != null) {
                    responseString.append(line);
                }

                // Log raw API response
                logger.info("Raw API Response: {}", responseString);

                // Parse JSON response
                ObjectMapper objectMapper = new ObjectMapper();
                JsonNode jsonResponse = objectMapper.readTree(responseString.toString());

                if (jsonResponse.has("candidates") && jsonResponse.get("candidates").size() > 0) {
                    JsonNode firstCandidate = jsonResponse.get("candidates").get(0);
                    if (firstCandidate.has("content") && firstCandidate.get("content").has("parts") &&
                            firstCandidate.get("content").get("parts").isArray() &&
                            firstCandidate.get("content").get("parts").size() > 0 &&
                            firstCandidate.get("content").get("parts").get(0).has("text")) {
                        return firstCandidate.get("content").get("parts").get(0).get("text").asText();
                    }
                }

                // Handle unexpected response
                logger.error("Unexpected JSON structure: {}", responseString);
                return "Sorry, I couldn't understand that. Please try again!";
            }
        } catch (Exception e) {
            logger.error("Exception in Gemini API call", e);
            return "Error: Unable to connect to AI service.";
        }
    }
}
