package com.gitam.hackthon.controller;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.gitam.hackthon.service.GeminiService;

@Controller
public class PortfolioController {

	 @Autowired
	    private GeminiService geminiService;
	
	 /*
	 @PostMapping("/analyzePortfolio")
	 @ResponseBody
	 public String analyzePortfolio(@RequestBody Map<String, Object> payload) {
	     List<Map<String, String>> investments = (List<Map<String, String>>) payload.get("investments");

	     StringBuilder prompt = new StringBuilder("📊 You are a smart investment analyst. Analyze this portfolio and give:\n");
	     prompt.append("- A short summary of the user's investment health\n");
	     prompt.append("- Risks (if any)\n");
	     prompt.append("- Portfolio diversification advice\n");
	     prompt.append("- 2-3 suggestions for improvement\n\n");

	     for (Map<String, String> inv : investments) {
	         prompt.append("➡️ Name: ").append(inv.get("name"))
	               .append(", Category: ").append(inv.get("category"))
	               .append(", Amount Invested: ₹").append(inv.get("amountInvested"))
	               .append(", Purchase Date: ").append(inv.get("purchaseDate"))
	               .append(", Quantity: ").append(inv.get("quantity"))
	               .append(", Live Price (INR): ₹").append(inv.get("livePriceINR"))
	               .append(", Total Worth: ₹").append(inv.get("totalWorth"))
	               .append(", Profit/Loss: ₹").append(inv.get("profitLoss"))
	               .append("\n");
	     }

	     return geminiService.getChatbotResponse(prompt.toString());
	 }

	 */
	 @PostMapping("/analyzePortfolio")
	 @ResponseBody
	 public String analyzePortfolio(@RequestBody Map<String, Object> payload) {
	     List<Map<String, String>> investments = (List<Map<String, String>>) payload.get("investments");
	     
	     // Calculate total portfolio value and other metrics for context
	     double totalInvested = 0;
	     double totalCurrentValue = 0;
	     double totalProfitLoss = 0;
	     
	     for (Map<String, String> inv : investments) {
	         try {
	             double invested = Double.parseDouble(inv.get("amountInvested"));
	             double worth = Double.parseDouble(inv.get("totalWorth"));
	             totalInvested += invested;
	             totalCurrentValue += worth;
	             totalProfitLoss += (worth - invested);
	         } catch (NumberFormatException | NullPointerException e) {
	             // Handle parsing errors gracefully
	         }
	     }
	     
	     // Format numbers for the prompt
	     String formattedTotalInvested = String.format("%.2f", totalInvested);
	     String formattedTotalValue = String.format("%.2f", totalCurrentValue);
	     String formattedProfitLoss = String.format("%.2f", totalProfitLoss);
	     double profitLossPercent = (totalInvested > 0) ? (totalProfitLoss / totalInvested) * 100 : 0;
	     String formattedProfitLossPercent = String.format("%.2f", profitLossPercent);
	     
	     StringBuilder prompt = new StringBuilder();
	     
	     // Professional introduction
	     prompt.append("# INVESTMENT PORTFOLIO ANALYSIS\n\n");
	     prompt.append("You are an elite financial analyst with expertise in wealth management and portfolio optimization. ");
	     prompt.append("Conduct a thorough, professional analysis of this investment portfolio worth ₹").append(formattedTotalValue);
	     prompt.append(" with a total investment of ₹").append(formattedTotalInvested).append(".\n\n");
	     
	     // Analysis requirements
	     prompt.append("## ANALYSIS REQUIREMENTS\n\n");
	     prompt.append("1. **Executive Summary**: Begin with a concise, professional summary of the portfolio's overall health, performance, and key metrics.\n\n");
	     prompt.append("2. **Performance Analysis**:\n");
	     prompt.append("   - Evaluate overall portfolio performance relative to market benchmarks\n");
	     prompt.append("   - Identify top performers and underperformers\n");
	     prompt.append("   - Calculate and interpret key performance indicators\n\n");
	     
	     prompt.append("3. **Risk Assessment**:\n");
	     prompt.append("   - Evaluate overall portfolio risk level (low, moderate, high)\n");
	     prompt.append("   - Identify potential vulnerabilities and concentration risks\n");
	     prompt.append("   - Assess risk-adjusted returns\n\n");
	     
	     prompt.append("4. **Diversification Analysis**:\n");
	     prompt.append("   - Evaluate asset allocation across different categories\n");
	     prompt.append("   - Identify overexposure or underexposure in specific sectors\n");
	     prompt.append("   - Recommend optimal diversification strategy\n\n");
	     
	     prompt.append("5. **Strategic Recommendations**:\n");
	     prompt.append("   - Provide 3-4 specific, actionable recommendations to optimize the portfolio\n");
	     prompt.append("   - Suggest rebalancing opportunities if applicable\n");
	     prompt.append("   - Recommend potential new investment categories to consider\n\n");
	     
	     prompt.append("6. **Future Outlook**:\n");
	     prompt.append("   - Provide a brief outlook for the portfolio's future performance\n");
	     prompt.append("   - Highlight potential market trends that may impact this specific portfolio\n\n");
	     
	     // Formatting instructions
	     prompt.append("## FORMATTING REQUIREMENTS\n\n");
	     prompt.append("- Use professional financial terminology throughout\n");
	     prompt.append("- Format the analysis with clear markdown headings and subheadings\n");
	     prompt.append("- Use bullet points for recommendations and key insights\n");
	     prompt.append("- Make strategic use of bold and italic text for emphasis\n");
	     prompt.append("- Include a few financial metrics and percentages to add credibility\n");
	     prompt.append("- Keep the analysis focused, concise, and actionable for a financial client\n");
	     prompt.append("- Include occasional financial wisdom or principles where relevant\n\n");
	     
	     // Portfolio overview
	     prompt.append("## PORTFOLIO DATA\n\n");
	     prompt.append("**Portfolio Summary:**\n");
	     prompt.append("- Total Investment: ₹").append(formattedTotalInvested).append("\n");
	     prompt.append("- Current Value: ₹").append(formattedTotalValue).append("\n");
	     prompt.append("- Total Profit/Loss: ₹").append(formattedProfitLoss)
	           .append(" (").append(formattedProfitLossPercent).append("%)\n\n");
	     
	     prompt.append("**Individual Investments:**\n\n");
	     
	     // Detailed investment data
	     for (Map<String, String> inv : investments) {
	         prompt.append("- **").append(inv.get("name")).append("**\n");
	         prompt.append("  - Category: ").append(inv.get("category")).append("\n");
	         prompt.append("  - Amount Invested: ₹").append(inv.get("amountInvested")).append("\n");
	         prompt.append("  - Purchase Date: ").append(inv.get("purchaseDate")).append("\n");
	         prompt.append("  - Quantity: ").append(inv.get("quantity")).append("\n");
	         prompt.append("  - Live Price (INR): ₹").append(inv.get("livePriceINR")).append("\n");
	         prompt.append("  - Total Worth: ₹").append(inv.get("totalWorth")).append("\n");
	         prompt.append("  - Profit/Loss: ₹").append(inv.get("profitLoss")).append("\n\n");
	     }
	     
	     // Final instructions
	     prompt.append("Present your analysis in a clear, professional format that would impress a high-net-worth client. ");
	     prompt.append("Be insightful, precise, and provide genuinely valuable financial advice that reflects deep expertise in wealth management. ");
	     prompt.append("The analysis should be presented as a professional financial document that is both informative and actionable.\n\n");
	     
	     return geminiService.getChatbotResponse(prompt.toString());
	 }
	 


}



