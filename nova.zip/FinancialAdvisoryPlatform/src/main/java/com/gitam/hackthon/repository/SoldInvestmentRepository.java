package com.gitam.hackthon.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.gitam.hackthon.model.SoldInvestment;

@Repository
public interface SoldInvestmentRepository extends JpaRepository<SoldInvestment, Long> {
    List<SoldInvestment> findByUserId(Long userId);
}
