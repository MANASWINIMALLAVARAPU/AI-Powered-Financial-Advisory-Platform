package com.gitam.hackthon.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.gitam.hackthon.model.User;
import com.gitam.hackthon.repository.UserRepository;

@Service
public class UserServiceImpl implements UserService
{

	
	@Autowired
	private UserRepository userRepository;

	@Override
	public String UserRegistration(User user) {
		userRepository.save(user);
		return "User Rgistered Successfully";
	}

	@Override
	public User checkuserlogin(String email, String upwd) {

		return userRepository.checkuserlogin(email, upwd);
	}
	
	

}
