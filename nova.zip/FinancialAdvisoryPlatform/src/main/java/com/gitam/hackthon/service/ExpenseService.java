package com.gitam.hackthon.service;

import com.gitam.hackthon.model.Expense;
import com.gitam.hackthon.model.User;
import com.gitam.hackthon.repository.ExpenseRepository;
import com.gitam.hackthon.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
public class ExpenseService {

    @Autowired
    private ExpenseRepository expenseRepository;

    @Autowired
    private UserRepository userRepository;

    // **Create Expense**
    public Expense addExpense(Expense expense, long userId) {
        User user = userRepository.findById((int) userId)
            .orElseThrow(() -> new RuntimeException("User not found"));
        expense.setUser(user);
        return expenseRepository.save(expense);
    }

    // **Get All Expenses for a User**
    public List<Expense> getExpensesByUser(long userId) {
        return expenseRepository.findByUserId(userId);
    }

    // **Get Total Expenses for a User**
    public double getTotalExpensesByUser(long userId) {
        return expenseRepository.findByUserId(userId)
               .stream().mapToDouble(Expense::getAmount).sum();
    }

    // **Monthly Expenses (Grouped by Month)**
    public Map<String, Double> getMonthlyExpenses(long userId) {
        List<Expense> expenses = expenseRepository.findByUserId(userId);
        return expenses.stream()
                .collect(Collectors.groupingBy(
                    expense -> expense.getDate().getYear() + "-" + (expense.getDate().getMonthValue()),
                    Collectors.summingDouble(Expense::getAmount)
                ));
    }

    // **Expenses by Category**
    public Map<String, Double> getExpensesByCategory(long userId) {
        List<Expense> expenses = expenseRepository.findByUserId(userId);
        return expenses.stream()
                .collect(Collectors.groupingBy(
                    Expense::getCategory, 
                    Collectors.summingDouble(Expense::getAmount)
                ));
    }

    // **Update Expense**
    public Expense updateExpense(Long id, Expense updatedExpense) {
        Expense existingExpense = expenseRepository.findById(id)
            .orElseThrow(() -> new RuntimeException("Expense not found"));

        existingExpense.setName(updatedExpense.getName());
        existingExpense.setAmount(updatedExpense.getAmount());
        existingExpense.setCategory(updatedExpense.getCategory());
        existingExpense.setDate(updatedExpense.getDate());
        existingExpense.setPaymentMethod(updatedExpense.getPaymentMethod());

        return expenseRepository.save(existingExpense);
    }

    // **Delete Expense**
    public void deleteExpense(Long id) {
        expenseRepository.deleteById(id);
    }

	public Expense getExpenseById(Long id) {
		// TODO Auto-generated method stub
		 return expenseRepository.findById(id).orElse(null); 
	}
}
