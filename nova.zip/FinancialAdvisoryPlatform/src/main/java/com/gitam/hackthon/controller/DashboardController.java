package com.gitam.hackthon.controller;

import com.gitam.hackthon.service.ExpenseService;
import com.gitam.hackthon.service.SavingsService;
import com.gitam.hackthon.model.*;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import jakarta.servlet.http.HttpSession;

import java.util.List;
import java.util.Map;

@Controller
public class DashboardController {

    @Autowired
    private ExpenseService expenseService;

    @Autowired
    private SavingsService savingsService;

    @GetMapping("/dashboard")
    public String showDashboard(HttpSession session, Model model) {
        // Retrieve User object from session
        User user = (User) session.getAttribute("user");

        if (user == null) {
            // Handle the case when user is not logged in or session has expired
            return "redirect:/login"; // Redirect to login page
        }

        // Fetch userId from the User object
        Long userId = (long) user.getId();

        // Fetch data from services
        double totalExpenses = expenseService.getTotalExpensesByUser(userId);
        double totalSavings = savingsService.getTotalSavingsByUser(userId);
        List<Expense> expenses = expenseService.getExpensesByUser(userId);
        List<Savings> savings = savingsService.getSavingsByUser(userId);

        // Monthly Trends
        Map<String, Double> monthlyExpenses = expenseService.getMonthlyExpenses(userId);
        Map<String, Double> monthlySavings = savingsService.getMonthlySavings(userId);

        // Category Breakdown
        Map<String, Double> expenseCategories = expenseService.getExpensesByCategory(userId);
        Map<String, Double> savingsCategories = savingsService.getSavingsByCategory(userId);

        // Add data to the model
        model.addAttribute("totalExpenses", totalExpenses);
        model.addAttribute("totalSavings", totalSavings);
        model.addAttribute("expenses", expenses);
        model.addAttribute("savings", savings);
        model.addAttribute("monthlyExpenses", monthlyExpenses);
        model.addAttribute("monthlySavings", monthlySavings);
        model.addAttribute("expenseCategories", expenseCategories);
        model.addAttribute("savingsCategories", savingsCategories);

        return "dashboard"; // Name of the JSP file
    }
}
