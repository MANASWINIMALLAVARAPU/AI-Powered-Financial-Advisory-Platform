package com.gitam.hackthon.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.gitam.hackthon.model.Investment;
import com.gitam.hackthon.repository.InvestmentRepository;

@Service
public class InvestmentService {
    @Autowired
    private InvestmentRepository investmentRepository;

    public void addInvestment(Investment investment) {
        investmentRepository.save(investment);
    }

    public List<Investment> getInvestmentsByUser(Long userId) {
        return investmentRepository.findByUserId(userId);
    }

    public Investment getInvestmentById(Long id) {
        return investmentRepository.findById(id).orElse(null);
    }

    public void updateInvestment(Long id, Investment updatedInvestment) {
        Investment investment = investmentRepository.findById(id).orElse(null);
        if (investment != null) {
            investment.setCurrentValue(updatedInvestment.getCurrentValue());
            investment.setExpectedReturn(updatedInvestment.getExpectedReturn());
            investmentRepository.save(investment);
        }
    }

    public void deleteInvestment(Long id) {
        investmentRepository.deleteById(id);
    }
}
