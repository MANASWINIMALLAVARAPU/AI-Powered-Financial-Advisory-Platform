package com.gitam.hackthon.controller;

import com.gitam.hackthon.model.Expense;
import com.gitam.hackthon.model.User;
import com.gitam.hackthon.service.ExpenseService;
import com.gitam.hackthon.service.UserService;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;

@Controller

public class ExpenseController {

    @Autowired
    private ExpenseService expenseService;

    @Autowired
    private UserService userService;

    // Show Add Expense Page
    @GetMapping("add")
    public String showAddExpenseForm() {
        return "addExpense";  // Corresponds to addExpense.jsp
    }

    // Add Expense (Handles form submission)
    @PostMapping("addexpense")
    public String addExpense(@RequestParam String name,
                             @RequestParam String category,
                             @RequestParam Double amount,
                             @RequestParam String paymentMethod,
                             @RequestParam String date, 
                             HttpSession session) {
    	User user = (User) session.getAttribute("user"); // Change "loggedInUser" to "user"
        if (user == null) {
            return "redirect:/login";  // Redirect to login if user is not logged in
        }

        Expense expense = new Expense();
        expense.setName(name);
        expense.setCategory(category);
        expense.setAmount(amount);
        expense.setPaymentMethod(paymentMethod);
        expense.setDate(LocalDate.parse(date));  // Convert String to LocalDate
        expense.setUser(user);

        expenseService.addExpense(expense, user.getId());
        return "redirect:/view";
    }

    // View All Expenses for Logged-in User
    @GetMapping("/view")
    public String viewExpenses(Model model, HttpSession session) {
    	User user = (User) session.getAttribute("user");

        if (user == null) {
            return "redirect:/login";  // Redirect to login if user is not logged in
        }

        List<Expense> expenses = expenseService.getExpensesByUser(user.getId());
        model.addAttribute("expenses", expenses);
        return "viewExpenses";  // Corresponds to viewExpenses.jsp
    }

    // Show Update Expense Form
    @GetMapping("/update")
    public String showUpdateExpenseForm(@RequestParam Long id, Model model) {
        Expense expense = expenseService.getExpenseById(id);
        if (expense == null) {
            return "redirect:/view";  // If expense not found, go back to list
        }
        model.addAttribute("expense", expense);
        return "updateExpense";  // Corresponds to updateExpense.jsp
    }

    // Update Expense (Handles form submission)
    @PostMapping("/update")
    public String updateExpense(@RequestParam Long id,
                                @RequestParam String name,
                                @RequestParam String category,
                                @RequestParam Double amount,
                                @RequestParam String paymentMethod,
                                @RequestParam String date) {
        Expense expense = new Expense();
        expense.setId(id);
        expense.setName(name);
        expense.setCategory(category);
        expense.setAmount(amount);
        expense.setPaymentMethod(paymentMethod);
        expense.setDate(LocalDate.parse(date));

        expenseService.updateExpense(id, expense);
        return "redirect:view";
    }

    // Delete Expense
    @PostMapping("/delete")
    public String deleteExpense(@RequestParam Long id) {
        expenseService.deleteExpense(id);
        return "redirect:view";
    }
    
    @GetMapping("track")
    public String trackexpenses() {
        return "trackpage";  // Corresponds to addExpense.jsp
    }
    
    @GetMapping("logout")
    public String logout() {
        return "userlogin";  // Corresponds to addExpense.jsp
    }
}
