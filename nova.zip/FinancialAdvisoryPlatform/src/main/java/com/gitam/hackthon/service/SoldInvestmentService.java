package com.gitam.hackthon.service;

import java.time.LocalDate;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.gitam.hackthon.model.Investment;
import com.gitam.hackthon.model.SoldInvestment;
import com.gitam.hackthon.repository.InvestmentRepository;
import com.gitam.hackthon.repository.SoldInvestmentRepository;

@Service
public class SoldInvestmentService {
    @Autowired
    private SoldInvestmentRepository soldInvestmentRepository;
    @Autowired
    private InvestmentRepository investmentRepository;

    public void addSoldInvestment(Long investmentId, Double soldPrice, LocalDate soldDate) {
        Investment investment = investmentRepository.findById(investmentId).orElse(null);
        if (investment == null) return;

        Double profitLoss = soldPrice - investment.getAmount();

        SoldInvestment soldInvestment = new SoldInvestment();
        soldInvestment.setInvestment(investment);
        soldInvestment.setUser(investment.getUser());
        soldInvestment.setName(investment.getName());
        soldInvestment.setAmountInvested(investment.getAmount());
        soldInvestment.setSoldPrice(soldPrice);
        soldInvestment.setProfitLoss(profitLoss);
        soldInvestment.setSoldDate(soldDate);

        soldInvestmentRepository.save(soldInvestment);
        investmentRepository.deleteById(investmentId); // Remove from active investments
    }

    public List<SoldInvestment> getSoldInvestmentsByUser(Long userId) {
        return soldInvestmentRepository.findByUserId(userId);
    }
}
