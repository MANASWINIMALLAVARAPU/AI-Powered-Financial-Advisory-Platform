package com.gitam.hackthon.model;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "investment_profiles")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class InvestmentProfile {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private String userEmail;

    @Column(nullable = false)
    private Double income;

    @Column(nullable = false)
    private Integer age;

    @Column(nullable = false)
    private Double savings;

    @Column(nullable = false)
    private String existingInvestments;

    @Column(nullable = false)
    private String financialGoal;

    @Column(nullable = false)
    private Boolean hasDebt;

    @Column(nullable = false)
    private String riskLevel;

    @Column(nullable = false)
    private String investmentType;

    @Column(nullable = false)
    private String investmentGoal;  // ✅ ADDED MISSING FIELD

    private Double monthlyExpenses;

    public Double getMonthlyExpenses() {
        return monthlyExpenses;
    }

    public void setMonthlyExpenses(Double monthlyExpenses) {
        this.monthlyExpenses = monthlyExpenses;
    }

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getUserEmail() {
		return userEmail;
	}

	public void setUserEmail(String userEmail) {
		this.userEmail = userEmail;
	}

	public Double getIncome() {
		return income;
	}

	public void setIncome(Double income) {
		this.income = income;
	}

	public Integer getAge() {
		return age;
	}

	public void setAge(Integer age) {
		this.age = age;
	}

	public Double getSavings() {
		return savings;
	}

	public void setSavings(Double savings) {
		this.savings = savings;
	}

	public String getExistingInvestments() {
		return existingInvestments;
	}

	public void setExistingInvestments(String existingInvestments) {
		this.existingInvestments = existingInvestments;
	}

	public String getFinancialGoal() {
		return financialGoal;
	}

	public void setFinancialGoal(String financialGoal) {
		this.financialGoal = financialGoal;
	}

	public Boolean getHasDebt() {
		return hasDebt;
	}

	public void setHasDebt(Boolean hasDebt) {
		this.hasDebt = hasDebt;
	}

	public String getRiskLevel() {
		return riskLevel;
	}

	public void setRiskLevel(String riskLevel) {
		this.riskLevel = riskLevel;
	}

	public String getInvestmentType() {
		return investmentType;
	}

	public void setInvestmentType(String investmentType) {
		this.investmentType = investmentType;
	}

	public String getInvestmentGoal() {
		return investmentGoal;
	}

	public void setInvestmentGoal(String investmentGoal) {
		this.investmentGoal = investmentGoal;
	}
}
