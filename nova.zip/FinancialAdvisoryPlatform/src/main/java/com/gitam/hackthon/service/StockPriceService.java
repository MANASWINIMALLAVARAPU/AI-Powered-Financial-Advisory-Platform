package com.gitam.hackthon.service;

import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

@Service
public class StockPriceService {

    // Finnhub (for US stocks)
    private static final String FINNHUB_API_KEY = "cvoa001r01qppf5bqekgcvoa001r01qppf5bqel0";
    private static final String FINNHUB_QUOTE_API = "https://finnhub.io/api/v1/quote?symbol=%s&token=" + FINNHUB_API_KEY;

    // Yahoo Finance (for Indian stocks) via RapidAPI
    private static final String RAPIDAPI_KEY = "your_rapidapi_key_here"; // 🔁 Replace this
    private static final String RAPIDAPI_HOST = "yahoo-finance15.p.rapidapi.com";
    private static final String YAHOO_QUOTE_API = "https://yahoo-finance15.p.rapidapi.com/api/yahoo/qu/quote/%s";

    private final RestTemplate restTemplate = new RestTemplate();

    private static final Map<String, String> stockSymbolMap = new HashMap<>();
    static {
        // US Stocks
        stockSymbolMap.put("Apple", "AAPL");
        stockSymbolMap.put("Nvidia", "NVDA");
        stockSymbolMap.put("Tesla", "TSLA");
        stockSymbolMap.put("Google", "GOOGL");
        stockSymbolMap.put("Microsoft", "MSFT");
        stockSymbolMap.put("Infosys", "INFY");
        stockSymbolMap.put("Amazon", "AMZN");
        stockSymbolMap.put("Meta", "META");
        stockSymbolMap.put("Netflix", "NFLX");
        stockSymbolMap.put("PayPal", "PYPL");
        stockSymbolMap.put("JP Morgan", "JPM");
        stockSymbolMap.put("Mastercard", "MA");
        stockSymbolMap.put("Visa", "V");
        stockSymbolMap.put("Bank of America", "BAC");
        stockSymbolMap.put("Salesforce", "CRM");
        stockSymbolMap.put("Adobe", "ADBE");
        stockSymbolMap.put("Oracle", "ORCL");
        stockSymbolMap.put("IBM", "IBM");
        stockSymbolMap.put("Uber", "UBER");
        stockSymbolMap.put("Zoom", "ZM");
        stockSymbolMap.put("Walmart", "WMT");
        stockSymbolMap.put("Coca Cola", "KO");
        stockSymbolMap.put("PepsiCo", "PEP");

        // Indian Stocks
        stockSymbolMap.put("TCS", "TCS.NS");
        stockSymbolMap.put("Reliance", "RELIANCE.NS");
        stockSymbolMap.put("Infosys India", "INFY.NS");
        stockSymbolMap.put("HDFC Bank", "HDFCBANK.NS");
        stockSymbolMap.put("ICICI Bank", "ICICIBANK.NS");
        stockSymbolMap.put("Wipro", "WIPRO.NS");
        stockSymbolMap.put("HCL", "HCLTECH.NS");
    }

    public Double getStockPrice(String stockName) {
        System.out.println("Fetching stock symbol for: " + stockName);
        String symbol = getStockSymbol(stockName);

        if (symbol == null || symbol.isEmpty()) {
            System.out.println("Invalid stock name: " + stockName);
            return null;
        }

        System.out.println("Resolved stock symbol: " + symbol);

        // Use Yahoo Finance for Indian stocks (ending with .NS or .BSE)
        if (symbol.endsWith(".NS") || symbol.endsWith(".BSE")) {
            return fetchFromYahooFinance(symbol);
        } else {
            return fetchFromFinnhub(symbol);
        }
    }

    private Double fetchFromFinnhub(String symbol) {
        try {
            String url = String.format(FINNHUB_QUOTE_API, symbol);
            String response = restTemplate.getForObject(url, String.class);
            System.out.println("Finnhub API Response: " + response);

            JSONObject json = new JSONObject(response);
            return json.has("c") ? json.getDouble("c") : null;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    private Double fetchFromYahooFinance(String symbol) {
        try {
            String url = String.format(YAHOO_QUOTE_API, symbol);
            HttpHeaders headers = new HttpHeaders();
            headers.set("X-RapidAPI-Key", RAPIDAPI_KEY);
            headers.set("X-RapidAPI-Host", RAPIDAPI_HOST);
            HttpEntity<String> entity = new HttpEntity<>(headers);

            ResponseEntity<String> response = restTemplate.exchange(url, HttpMethod.GET, entity, String.class);
            System.out.println("Yahoo Finance API Response: " + response.getBody());

            JSONObject json = new JSONObject(response.getBody());
            JSONObject quote = json.getJSONObject("quote");
            return quote.has("regularMarketPrice") ? quote.getDouble("regularMarketPrice") : null;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    private String getStockSymbol(String stockName) {
        return stockSymbolMap.getOrDefault(stockName, null);
    }
}
