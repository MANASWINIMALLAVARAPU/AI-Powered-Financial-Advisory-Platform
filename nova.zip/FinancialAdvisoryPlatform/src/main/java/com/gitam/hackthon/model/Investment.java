package com.gitam.hackthon.model;

import java.time.LocalDate;
import jakarta.persistence.*;

@Entity
public class Investment {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "user_id", nullable = false)
    private User user;

    private String name;  // Stock name, Mutual Fund name, etc.
    private Double amount; // Amount invested
    private String category; // Stock, Crypto, Gold, etc.
    private LocalDate purchaseDate;
    private Double quantity = 0.0; // NEW - Number of units purchased
    private Double currentValue; // Auto-updated from live stock prices
    private Double expectedReturn; // Future expected returns

    // Getters and Setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public User getUser() { return user; }
    public void setUser(User user) { this.user = user; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public Double getAmount() { return amount; }
    public void setAmount(Double amount) { this.amount = amount; }

    public String getCategory() { return category; }
    public void setCategory(String category) { this.category = category; }

    public LocalDate getPurchaseDate() { return purchaseDate; }
    public void setPurchaseDate(LocalDate purchaseDate) { this.purchaseDate = purchaseDate; }

    public Double getQuantity() {return quantity != null ? quantity : 0.0; }
    public void setQuantity(Double quantity) { this.quantity = (quantity != null) ? quantity : 0.0; }

    public Double getCurrentValue() { return currentValue; }
    public void setCurrentValue(Double currentValue) { this.currentValue = currentValue; }

    public Double getExpectedReturn() { return expectedReturn; }
    public void setExpectedReturn(Double expectedReturn) { this.expectedReturn = expectedReturn; }
}
