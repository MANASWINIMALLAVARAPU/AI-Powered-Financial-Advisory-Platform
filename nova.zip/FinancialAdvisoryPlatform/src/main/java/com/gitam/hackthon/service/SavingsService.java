package com.gitam.hackthon.service;

import com.gitam.hackthon.model.Savings;
import com.gitam.hackthon.model.User;
import com.gitam.hackthon.repository.SavingsRepository;
import com.gitam.hackthon.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
public class SavingsService {

    @Autowired
    private SavingsRepository savingsRepository;

    @Autowired
    private UserRepository userRepository;

    // **Create Savings**
    public Savings addSavings(Savings savings, long userId) {
        User user = userRepository.findById((int) userId)
            .orElseThrow(() -> new RuntimeException("User not found"));
        savings.setUser(user);
        return savingsRepository.save(savings);
    }

    // **Get All Savings for a User**
    public List<Savings> getSavingsByUser(long userId) {
        return savingsRepository.findByUserId(userId);
    }

    // **Get Total Savings for a User**
    public double getTotalSavingsByUser(long userId) {
        return savingsRepository.findByUserId(userId)
               .stream().mapToDouble(Savings::getAmount).sum();
    }

    // **Monthly Savings (Grouped by Month)**
    public Map<String, Double> getMonthlySavings(long userId) {
        List<Savings> savings = savingsRepository.findByUserId(userId);
        return savings.stream()
                .collect(Collectors.groupingBy(
                    saving -> saving.getDate().getYear() + "-" + (saving.getDate().getMonthValue()),
                    Collectors.summingDouble(Savings::getAmount)
                ));
    }

    // **Savings by Category**
    public Map<String, Double> getSavingsByCategory(long userId) {
        List<Savings> savings = savingsRepository.findByUserId(userId);
        return savings.stream()
                .collect(Collectors.groupingBy(
                    Savings::getCategory,
                    Collectors.summingDouble(Savings::getAmount)
                ));
    }

    // **Update Savings**
    public Savings updateSavings(Long id, Savings updatedSavings) {
        Savings existingSavings = savingsRepository.findById(id)
            .orElseThrow(() -> new RuntimeException("Saving not found"));

        existingSavings.setName(updatedSavings.getName());
        existingSavings.setAmount(updatedSavings.getAmount());
        existingSavings.setCategory(updatedSavings.getCategory());
        existingSavings.setDate(updatedSavings.getDate());

        return savingsRepository.save(existingSavings);
    }

    // **Delete Savings**
    public void deleteSavings(Long id) {
        savingsRepository.deleteById(id);
    }

	public Savings getSavingsById(Long id) {
		// TODO Auto-generated method stub
		 return savingsRepository.findById(id).orElse(null); 
	}
}
