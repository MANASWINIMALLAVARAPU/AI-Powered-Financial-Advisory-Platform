package com.gitam.hackthon.controller;

import java.time.LocalDate;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.gitam.hackthon.model.SoldInvestment;
import com.gitam.hackthon.model.User;
import com.gitam.hackthon.service.SoldInvestmentService;
import com.gitam.hackthon.service.UserService;

import jakarta.servlet.http.HttpSession;

@Controller
public class SoldInvestmentController {
    @Autowired
    private SoldInvestmentService soldInvestmentService;
    @Autowired
    private UserService userService;

    @PostMapping("/sellInvestment")
    public String sellInvestment(@RequestParam Long id,
                                 @RequestParam Double soldPrice,
                                 @RequestParam String soldDate) {
        soldInvestmentService.addSoldInvestment(id, soldPrice, LocalDate.parse(soldDate));
        return "redirect:/viewSoldInvestments";
    }

    @GetMapping("/viewSoldInvestments")
    public String viewSoldInvestments(Model model, HttpSession session) {
        User user = (User) session.getAttribute("user");
        if (user == null) return "redirect:/login";

        List<SoldInvestment> soldInvestments = soldInvestmentService.getSoldInvestmentsByUser((long) user.getId());
        model.addAttribute("soldInvestments", soldInvestments);
        return "viewSoldInvestments";
    }
}
