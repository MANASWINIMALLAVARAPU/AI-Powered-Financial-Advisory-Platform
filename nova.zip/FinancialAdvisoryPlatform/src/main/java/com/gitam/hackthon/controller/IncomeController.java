package com.gitam.hackthon.controller;

import com.gitam.hackthon.model.Income;
import com.gitam.hackthon.model.User;
import com.gitam.hackthon.service.IncomeService;
import com.gitam.hackthon.service.UserService;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;

@Controller
public class IncomeController {

    @Autowired
    private IncomeService incomeService;

    @Autowired
    private UserService userService;

    // Show Add Income Page
    @GetMapping("addIncome")
    public String showAddIncomeForm() {
        return "addIncome";  // Corresponds to addIncome.jsp
    }

    // Add Income (Handles form submission)
    @PostMapping("addincome")
    public String addIncome(@RequestParam String name,
                            @RequestParam Double amount,
                            @RequestParam String category,
                            @RequestParam String date,
                            HttpSession session) {
        User user = (User) session.getAttribute("user");
        if (user == null) {
            return "redirect:/login";  // Redirect to login if user is not logged in
        }

        Income income = new Income();
        income.setName(name);
        income.setAmount(amount);
        income.setCategory(category);
        income.setDate(LocalDate.parse(date));
        income.setUser(user);

        incomeService.addIncome(income, user.getId());
        return "redirect:/viewIncome";
    }

    // View All Income for Logged-in User
    @GetMapping("/viewIncome")
    public String viewIncome(Model model, HttpSession session) {
        User user = (User) session.getAttribute("user");

        if (user == null) {
            return "redirect:/login";  // Redirect to login if user is not logged in
        }

        List<Income> incomeList = incomeService.getIncomeByUser(user.getId());
        model.addAttribute("income", incomeList);
        return "viewIncome";  // Corresponds to viewIncome.jsp
    }

    // Show Update Income Form
    @GetMapping("/updateIncome")
    public String showUpdateIncomeForm(@RequestParam Long id, Model model) {
        Income income = incomeService.getIncomeById(id);
        if (income == null) {
            return "redirect:/viewIncome";
        }
        model.addAttribute("income", income);
        return "updateIncome";  // Corresponds to updateIncome.jsp
    }

    // Update Income (Handles form submission)
    @PostMapping("/updateIncome")
    public String updateIncome(@RequestParam Long id,
                               @RequestParam String name,
                               @RequestParam Double amount,
                               @RequestParam String category,
                               @RequestParam String date) {
        Income income = new Income();
        income.setId(id);
        income.setName(name);
        income.setAmount(amount);
        income.setCategory(category);
        income.setDate(LocalDate.parse(date));

        incomeService.updateIncome(id, income);
        return "redirect:viewIncome";
    }

    // Delete Income
    @PostMapping("/deleteIncome")
    public String deleteIncome(@RequestParam Long id) {
        incomeService.deleteIncome(id);
        return "redirect:viewIncome";
    }
}
