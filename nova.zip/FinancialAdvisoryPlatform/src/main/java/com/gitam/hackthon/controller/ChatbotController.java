package com.gitam.hackthon.controller;

import com.gitam.hackthon.service.ChatbotService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/chatbot")
@CrossOrigin(origins = "*") // Allows frontend access
public class ChatbotController {

    @Autowired
    private ChatbotService chatbotService;

    @PostMapping("/ask")
    public String askQuestion(@RequestParam String message) {
        return chatbotService.getChatResponse(message);
    }
}
