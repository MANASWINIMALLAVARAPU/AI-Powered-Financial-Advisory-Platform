package com.gitam.hackthon.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.gitam.hackthon.model.InvestmentProfile;
import org.apache.hc.client5.http.classic.methods.HttpPost;
import org.apache.hc.client5.http.impl.classic.CloseableHttpClient;
import org.apache.hc.client5.http.impl.classic.CloseableHttpResponse;
import org.apache.hc.client5.http.impl.classic.HttpClients;
import org.apache.hc.core5.http.io.entity.StringEntity;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import org.springframework.web.reactive.function.client.WebClient;

@Service
public class GeminiService {

	
	

	
    private static final Logger logger = LoggerFactory.getLogger(GeminiService.class);
    private static final String API_KEY = "AIzaSyCoupOtlODD2oSbf4wW2sQBdxrvx2mIAo0"; // 🔴 Replace with your valid API key
    private static final String API_URL = "https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-pro-latest:generateContent?key=" + API_KEY;

  


    public String getInvestmentAdvice(InvestmentProfile profile) {
        try (CloseableHttpClient client = HttpClients.createDefault()) {
            HttpPost request = new HttpPost(API_URL);
            request.addHeader("Content-Type", "application/json");

            // ✅ Generate a properly formatted prompt
            String prompt = generatePrompt(profile);

            // ✅ Correct API request format
            String jsonBody = "{ \"contents\": [{ \"parts\": [{ \"text\": \"" + prompt + "\" }] }] }";
            request.setEntity(new StringEntity(jsonBody, StandardCharsets.UTF_8));

            try (CloseableHttpResponse response = client.execute(request);
                 BufferedReader reader = new BufferedReader(new InputStreamReader(response.getEntity().getContent(), StandardCharsets.UTF_8))) {

                StringBuilder responseString = new StringBuilder();
                String line;
                while ((line = reader.readLine()) != null) {
                    responseString.append(line);
                }

                // 📌 Log the raw API response
                logger.info("Raw API Response: {}", responseString);

                // ✅ Parse JSON response
                ObjectMapper objectMapper = new ObjectMapper();
                JsonNode jsonResponse = objectMapper.readTree(responseString.toString());

                // 📌 Handle potential API errors
                if (jsonResponse.has("error")) {
                    String errorMessage = jsonResponse.get("error").get("message").asText();
                    logger.error("API Error: {}", errorMessage);
                    return "Error: " + errorMessage;
                }

                // ✅ Extract generated text safely
                if (jsonResponse.has("candidates") && jsonResponse.get("candidates").size() > 0) {
                    JsonNode firstCandidate = jsonResponse.get("candidates").get(0);
                    if (firstCandidate.has("content") && firstCandidate.get("content").has("parts") &&
                            firstCandidate.get("content").get("parts").isArray() &&
                            firstCandidate.get("content").get("parts").size() > 0 &&
                            firstCandidate.get("content").get("parts").get(0).has("text")) {
                        return firstCandidate.get("content").get("parts").get(0).get("text").asText();
                    }
                }

                // 🔴 Handle unexpected response structure
                logger.error("Unexpected JSON structure: {}", responseString);
                return "Error: Unexpected response format. Please try again later.";
            }
        } catch (Exception e) {
            logger.error("Exception in Gemini API call", e);
            return "Error: Unable to connect to the AI service. Please try again later.";
        }
    }

    private String generatePrompt(InvestmentProfile profile) {
        // Calculate some derived metrics for better analysis
        double monthlyIncome = profile.getIncome() / 12.0;
        double estimatedMonthlyExpenses = profile.getMonthlyExpenses() != null ? 
            profile.getMonthlyExpenses() : monthlyIncome * 0.5;
        double monthlySavingCapacity = monthlyIncome - estimatedMonthlyExpenses;
        int investmentTimeframeYears = calculateTimeframeFromGoal(profile.getFinancialGoal(), profile);
        
        return "You are an elite financial advisor with expertise in personal finance, investment planning, and wealth management. "
                + "Create a comprehensive, personalized investment strategy that addresses the client's unique financial situation, goals, and risk profile. "
                + "Your analysis should be thorough but presented in an accessible, actionable way.\n\n"

                + "## CLIENT PROFILE\n"
                + "• Age: " + profile.getAge() + " years\n"
                + "• Annual Income: ₹" + formatCurrency(profile.getIncome()) + "\n"
                + "• Monthly Income: ₹" + formatCurrency(monthlyIncome) + "\n"
                + "• Monthly Expenses: ₹" + formatCurrency(estimatedMonthlyExpenses) + "\n"
                + "• Monthly Saving Capacity: ₹" + formatCurrency(monthlySavingCapacity) + "\n"
                + "• Current Savings: ₹" + formatCurrency(profile.getSavings()) + "\n"
                + "• Existing Investments: " + profile.getExistingInvestments() + "\n"
                + "• Financial Goal: " + profile.getFinancialGoal() + "\n"
                + "• Time Horizon: Approximately " + investmentTimeframeYears + " years\n"
                + "• Debt Status: " + (profile.getHasDebt() ? "Has outstanding debt" : "No significant debt") + "\n"
                + "• Risk Tolerance: " + profile.getRiskLevel() + "\n"
                + "• Investment Preferences: " + profile.getInvestmentType() + "\n"
                + "• Primary Investment Objective: " + profile.getInvestmentGoal() + "\n\n"

                + "## MARKET CONTEXT\n"
                + "• Current market conditions in India favor [analyze based on client profile and goals]\n"
                + "• Recent performance of relevant asset classes (equities, debt, gold, etc.)\n"
                + "• Key economic indicators affecting investment decisions\n\n"

                + "## DETAILED ADVISORY FRAMEWORK\n\n"

                + "### 1. EXECUTIVE SUMMARY\n"
                + "Provide a concise 3-5 sentence overview of your key recommendations and the investment philosophy guiding your advice.\n\n"

                + "### 2. ASSET ALLOCATION STRATEGY\n"
                + "• Create a precise percentage breakdown of recommended asset allocation\n"
                + "• Explain the rationale behind this allocation based on client's age, risk tolerance, and goals\n"
                + "• Address how this allocation balances growth potential with downside protection\n\n"

                + "### 3. INVESTMENT VEHICLES AND PRODUCTS\n"
                + "• Recommend specific investment categories suitable for this client\n"
                + "• For each category, explain why it's appropriate given the client profile\n"
                + "• Provide sample allocations (e.g., \\\"Consider allocating ₹X monthly to large-cap equity funds\\\")\n\n"

                + "### 4. FINANCIAL ROADMAP\n"
                + "• Short-term actions (0-12 months): Immediate steps the client should take\n"
                + "• Medium-term strategy (1-5 years): Building phase objectives and milestones\n"
                + "• Long-term vision (5+ years): How investments align with ultimate financial goals\n\n"

                + "### 5. RISK MANAGEMENT AND SAFEGUARDS\n"
                + "• Diversification strategy to mitigate market volatility\n"
                + "• Recommended insurance coverage based on life stage and financial responsibilities\n"
                + "• Emergency fund guidelines specific to client's situation\n\n"

                + "### 6. TAX OPTIMIZATION\n"
                + "• Tax-efficient investment vehicles relevant to client's situation\n"
                + "• Section 80C deduction opportunities\n"
                + "• Other tax planning strategies based on current Indian tax code\n\n"

                + "### 7. BEHAVIORAL GUIDANCE\n"
                + "• Common psychological biases to avoid when implementing this plan\n"
                + "• How to maintain discipline during market fluctuations\n"
                + "• When to revisit and potentially adjust the investment strategy\n\n"

                + "### 8. LIQUIDITY CONSIDERATIONS\n"
                + "• Balancing long-term investments with access to funds when needed\n"
                + "• Recommended emergency fund size based on client circumstances\n\n"

                + "### 9. ALTERNATIVE STRATEGIES\n"
                + "• Present one more conservative and one more aggressive alternative to your main recommendation\n"
                + "• Briefly explain the risk/reward tradeoffs of each approach\n\n"

                + "## PRESENTATION GUIDELINES\n"
                + "• Use clear, jargon-free language while still conveying sophisticated financial concepts\n"
                + "• Include specific numbers and percentages whenever possible\n"
                + "• Format your response with headers, bullet points, and occasional bold text for emphasis\n"
                + "• Adopt a confident, reassuring tone that inspires trust while acknowledging investment uncertainties\n"
                + "• Include a short glossary of any financial terms that may be unfamiliar\n\n"

                + "## DISCLAIMER\n"
                + "Close with a brief disclaimer emphasizing that this advice is for informational purposes and that individual consultation with a registered financial advisor is recommended before making significant investment decisions.\n\n"

                + "Make sure your advice is highly personalized to this specific client's financial situation, goals, and risk tolerance. Avoid generic recommendations that could apply to anyone.";
    }

    /**
     * Helper method to format currency values with commas
     */
    private String formatCurrency(double amount) {
        return String.format("%,.2f", amount);
    }

    /**
     * Helper method to estimate timeframe based on financial goal
     */
    private int calculateTimeframeFromGoal(String financialGoal, InvestmentProfile profile) {
        String goalLower = financialGoal.toLowerCase();
        
        if (goalLower.contains("retirement")) {
            // Estimate retirement timeframe based on standard retirement age minus current age
            return Math.max(5, 60 - profile.getAge());
        } else if (goalLower.contains("education") || goalLower.contains("college")) {
            return 5; // Typical education planning timeframe
        } else if (goalLower.contains("house") || goalLower.contains("home")) {
            return 7; // Typical home purchase planning timeframe
        } else if (goalLower.contains("short") || goalLower.contains("vacation")) {
            return 2; // Short-term goals
        } else if (goalLower.contains("long") || goalLower.contains("wealth")) {
            return 15; // Long-term wealth building
        } else {
            return 10; // Default medium-term timeframe
        }
    }
    
    public String getChatbotResponse(String userMessage) {
        try (CloseableHttpClient client = HttpClients.createDefault()) {
            HttpPost request = new HttpPost(API_URL);
            request.addHeader("Content-Type", "application/json");

            // 🔹 User message formatted as a chatbot conversation
            String jsonBody = "{ \"contents\": [{ \"parts\": [{ \"text\": \"" + userMessage + "\" }] }] }";
            request.setEntity(new StringEntity(jsonBody, StandardCharsets.UTF_8));

            try (CloseableHttpResponse response = client.execute(request);
                 BufferedReader reader = new BufferedReader(new InputStreamReader(response.getEntity().getContent(), StandardCharsets.UTF_8))) {

                StringBuilder responseString = new StringBuilder();
                String line;
                while ((line = reader.readLine()) != null) {
                    responseString.append(line);
                }

                // 📌 Parse response
                ObjectMapper objectMapper = new ObjectMapper();
                JsonNode jsonResponse = objectMapper.readTree(responseString.toString());

                if (jsonResponse.has("candidates") && jsonResponse.get("candidates").size() > 0) {
                    JsonNode firstCandidate = jsonResponse.get("candidates").get(0);
                    if (firstCandidate.has("content") && firstCandidate.get("content").has("parts") &&
                            firstCandidate.get("content").get("parts").size() > 0 &&
                            firstCandidate.get("content").get("parts").get(0).has("text")) {
                        return firstCandidate.get("content").get("parts").get(0).get("text").asText();
                    }
                }
                logger.warn("Gemini returned no candidates or invalid format: {}", responseString);

                return "I'm sorry, I couldn't understand that.";
            }
        } catch (Exception e) {
            logger.error("Error in chatbot response", e);
            return "Sorry, there was an error processing your request.";
        }
    }


}