package com.gitam.hackthon.controller;

import com.gitam.hackthon.model.Savings;
import com.gitam.hackthon.model.User;
import com.gitam.hackthon.service.SavingsService;
import com.gitam.hackthon.service.UserService;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;

@Controller
public class SavingsController {

    @Autowired
    private SavingsService savingsService;

    @Autowired
    private UserService userService;

    // Show Add Savings Page
    @GetMapping("addSavings")
    public String showAddSavingsForm() {
        return "addSavings";  // Corresponds to addSavings.jsp
    }

    // Add Savings (Handles form submission)
    @PostMapping("addsaving")
    public String addSaving(@RequestParam String name,
                            @RequestParam Double amount,
                            @RequestParam String category,
                            @RequestParam String date,
                            HttpSession session) {
        User user = (User) session.getAttribute("user");
        if (user == null) {
            return "redirect:/login";  // Redirect to login if user is not logged in
        }

        Savings savings = new Savings();
        savings.setName(name);
        savings.setAmount(amount);
        savings.setCategory(category);
        savings.setDate(LocalDate.parse(date));
        savings.setUser(user);

        savingsService.addSavings(savings, user.getId());
        return "redirect:/viewSavings";
    }

    // View All Savings for Logged-in User
    @GetMapping("/viewSavings")
    public String viewSavings(Model model, HttpSession session) {
        User user = (User) session.getAttribute("user");

        if (user == null) {
            return "redirect:/login";  // Redirect to login if user is not logged in
        }

        List<Savings> savingsList = savingsService.getSavingsByUser(user.getId());
        model.addAttribute("savings", savingsList);
        return "viewSavings";  // Corresponds to viewSavings.jsp
    }

    // Show Update Savings Form
    @GetMapping("/updateSavings")
    public String showUpdateSavingsForm(@RequestParam Long id, Model model) {
        Savings savings = savingsService.getSavingsById(id);
        if (savings == null) {
            return "redirect:/viewSavings";
        }
        model.addAttribute("savings", savings);
        return "updateSavings";  // Corresponds to updateSavings.jsp
    }

    // Update Savings (Handles form submission)
    @PostMapping("/updateSavings")
    public String updateSavings(@RequestParam Long id,
                                @RequestParam String name,
                                @RequestParam Double amount,
                                @RequestParam String category,
                                @RequestParam String date) {
        Savings savings = new Savings();
        savings.setId(id);
        savings.setName(name);
        savings.setAmount(amount);
        savings.setCategory(category);
        savings.setDate(LocalDate.parse(date));

        savingsService.updateSavings(id, savings);
        return "redirect:viewSavings";
    }

    // Delete Savings
    @PostMapping("/deleteSavings")
    public String deleteSavings(@RequestParam Long id) {
        savingsService.deleteSavings(id);
        return "redirect:viewSavings";
    }
}
