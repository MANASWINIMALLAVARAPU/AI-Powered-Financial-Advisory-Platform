package com.gitam.hackthon.controller;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.gitam.hackthon.model.Investment;
import com.gitam.hackthon.model.User;
import com.gitam.hackthon.service.InvestmentService;
import com.gitam.hackthon.service.StockPriceService;
import com.gitam.hackthon.service.UserService;

import com.gitam.hackthon.model.Expense;
import com.gitam.hackthon.model.User;


import java.time.LocalDate;

import jakarta.servlet.http.HttpSession;

@Controller
public class InvestmentController {
    @Autowired
    private InvestmentService investmentService;
    @Autowired
    private UserService userService;

    @GetMapping("/addInvestment")
    public String showAddInvestmentForm() {
        return "addInvestment";  // Corresponds to addInvestment.jsp
    }

    @PostMapping("/addInvestment")
    public String addInvestment(@RequestParam String name,
                                @RequestParam Double amount,
                                @RequestParam String category,
                                @RequestParam Double quantity,
                                @RequestParam String purchaseDate,
                                HttpSession session) {
        User user = (User) session.getAttribute("user");
        if (user == null) return "redirect:/login";

        Investment investment = new Investment();
        investment.setName(name);
        investment.setAmount(amount);
        investment.setCategory(category);
        investment.setQuantity(quantity);
        investment.setPurchaseDate(LocalDate.parse(purchaseDate));
        investment.setUser(user);

        // Fetch real-time price if it's a stock or crypto
        if ("Stock".equalsIgnoreCase(category) || "Crypto".equalsIgnoreCase(category)) {
            Double latestPrice = stockPriceService.getStockPrice(name);
            if (latestPrice != null) {
                investment.setCurrentValue(latestPrice * quantity); // Auto-calculate
            }
        }

        investmentService.addInvestment(investment);
        return "redirect:/viewInvestments";
    }


    @Autowired
    private StockPriceService stockPriceService;

    @GetMapping("/viewInvestments")
    public String viewInvestments(Model model, HttpSession session) {
        User user = (User) session.getAttribute("user");

        if (user == null) {
            return "redirect:/login";
        }

        List<Investment> investments = investmentService.getInvestmentsByUser((long) user.getId());

        double inrConversionRate = 83.0; // Fetch dynamically if needed

        for (Investment investment : investments) {
            if ("Stock".equalsIgnoreCase(investment.getCategory()) || "Crypto".equalsIgnoreCase(investment.getCategory())) {
                Double latestPriceUSD = stockPriceService.getStockPrice(investment.getName());
                if (latestPriceUSD != null) {
                    double latestPriceINR = latestPriceUSD * inrConversionRate; // Convert to INR
                    double totalWorthINR = latestPriceINR * investment.getQuantity();

                    investment.setCurrentValue(latestPriceINR); // Live INR price per unit
                    investment.setExpectedReturn(totalWorthINR); // Total Worth in INR

                    investmentService.updateInvestment(investment.getId(), investment);
                }
            }
        }

        model.addAttribute("investments", investments);
        return "viewInvestments";
    }



    @GetMapping("/updateInvestment")
    public String showUpdateInvestmentForm(@RequestParam Long id, Model model, HttpSession session) {
        User user = (User) session.getAttribute("user");
        if (user == null) return "redirect:/login";

        Investment investment = investmentService.getInvestmentById(id);
        if (investment == null || investment.getUser().getId() != user.getId()) {  
            return "redirect:/viewInvestments"; // Security check
        }

        model.addAttribute("investment", investment);
        return "updateInvestment";  // Renders updateInvestment.jsp
    }


    @PostMapping("/updateInvestment")
    public String updateInvestment(@RequestParam Long id,
                                   @RequestParam Double currentValue,
                                   @RequestParam Double expectedReturn) {
        Investment investment = investmentService.getInvestmentById(id);
        if (investment == null) return "redirect:/viewInvestments";

        investment.setCurrentValue(currentValue);
        investment.setExpectedReturn(expectedReturn);
        investmentService.updateInvestment(id, investment);

        return "redirect:/viewInvestments";
    }
    
    @GetMapping("/invest")
    public String advancePage() {
        return "invest";
    }

}
