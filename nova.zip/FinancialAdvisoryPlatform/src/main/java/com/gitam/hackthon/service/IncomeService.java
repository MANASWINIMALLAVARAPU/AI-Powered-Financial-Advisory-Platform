package com.gitam.hackthon.service;

import com.gitam.hackthon.model.Income;
import com.gitam.hackthon.model.User;
import com.gitam.hackthon.repository.IncomeRepository;
import com.gitam.hackthon.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
public class IncomeService {

    @Autowired
    private IncomeRepository incomeRepository;

    @Autowired
    private UserRepository userRepository;

    // **Create Income**
    public Income addIncome(Income income, long userId) {
        User user = userRepository.findById((int) userId)
            .orElseThrow(() -> new RuntimeException("User not found"));
        income.setUser(user);
        return incomeRepository.save(income);
    }

    // **Get All Income for a User**
    public List<Income> getIncomeByUser(long userId) {
        return incomeRepository.findByUserId(userId);
    }

    // **Get Total Income for a User**
    public double getTotalIncomeByUser(long userId) {
        return incomeRepository.findByUserId(userId)
               .stream().mapToDouble(Income::getAmount).sum();
    }

    // **Monthly Income (Grouped by Month)**
    public Map<String, Double> getMonthlyIncome(long userId) {
        List<Income> income = incomeRepository.findByUserId(userId);
        return income.stream()
                .collect(Collectors.groupingBy(
                    incomeItem -> incomeItem.getDate().getYear() + "-" + (incomeItem.getDate().getMonthValue()),
                    Collectors.summingDouble(Income::getAmount)
                ));
    }

    // **Income by Category**
    public Map<String, Double> getIncomeByCategory(long userId) {
        List<Income> income = incomeRepository.findByUserId(userId);
        return income.stream()
                .collect(Collectors.groupingBy(
                    Income::getCategory,
                    Collectors.summingDouble(Income::getAmount)
                ));
    }

    // **Update Income**
    public Income updateIncome(Long id, Income updatedIncome) {
        Income existingIncome = incomeRepository.findById(id)
            .orElseThrow(() -> new RuntimeException("Income not found"));

        existingIncome.setName(updatedIncome.getName());
        existingIncome.setAmount(updatedIncome.getAmount());
        existingIncome.setCategory(updatedIncome.getCategory());
        existingIncome.setDate(updatedIncome.getDate());

        return incomeRepository.save(existingIncome);
    }

    // **Delete Income**
    public void deleteIncome(Long id) {
        incomeRepository.deleteById(id);
    }

    public Income getIncomeById(Long id) {
        return incomeRepository.findById(id).orElse(null);
    }
}
