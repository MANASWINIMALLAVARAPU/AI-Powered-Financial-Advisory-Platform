package com.gitam.hackthon;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FinancialAdvisoryPlatformApplication {

	public static void main(String[] args) {
		SpringApplication.run(FinancialAdvisoryPlatformApplication.class, args);
	}

}
