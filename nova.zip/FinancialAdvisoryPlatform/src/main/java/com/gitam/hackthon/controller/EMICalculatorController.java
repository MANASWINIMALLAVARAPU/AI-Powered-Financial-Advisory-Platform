package com.gitam.hackthon.controller;


//Updated Controller class for JSP


import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class EMICalculatorController {

 @GetMapping("calculator")
 public String index() {
     return "calculator"; // calculator.jsp
 }
 
 @PostMapping("/calculate")
 public String calculate(
         @RequestParam(required = false) Double principal,
         @RequestParam(required = false) Double interestRate,
         @RequestParam(required = false) Integer months,
         @RequestParam(required = false) Double emi,
         @RequestParam String calculateType,
         Model model
 ) {
     model.addAttribute("selectedCalculation", calculateType);
     
     try {
         switch (calculateType) {
             case "emi":
                 // Calculate EMI
                 if (principal == null || interestRate == null || months == null) {
                     throw new IllegalArgumentException("Principal, interest rate, and months are required to calculate EMI");
                 }
                 double calculatedEmi = calculateEMI(principal, interestRate, months);
                 model.addAttribute("result", String.format("%.2f", calculatedEmi));
                 break;
                 
             case "principal":
                 // Calculate Principal
                 if (emi == null || interestRate == null || months == null) {
                     throw new IllegalArgumentException("EMI, interest rate, and months are required to calculate Principal");
                 }
                 double calculatedPrincipal = calculatePrincipal(emi, interestRate, months);
                 model.addAttribute("result", String.format("%.2f", calculatedPrincipal));
                 break;
                 
             case "interest":
                 // Calculate Interest Rate
                 if (principal == null || emi == null || months == null) {
                     throw new IllegalArgumentException("Principal, EMI, and months are required to calculate Interest Rate");
                 }
                 double calculatedInterest = calculateInterestRate(principal, emi, months);
                 model.addAttribute("result", String.format("%.2f", calculatedInterest));
                 break;
                 
             case "months":
                 // Calculate Months
                 if (principal == null || interestRate == null || emi == null) {
                     throw new IllegalArgumentException("Principal, interest rate, and EMI are required to calculate Months");
                 }
                 int calculatedMonths = calculateMonths(principal, interestRate, emi);
                 model.addAttribute("result", String.valueOf(calculatedMonths));
                 break;
                 
             default:
                 throw new IllegalArgumentException("Invalid calculation type");
         }
     } catch (Exception e) {
         model.addAttribute("error", e.getMessage());
     }
     
     // Pass back the original values
     model.addAttribute("principal", principal);
     model.addAttribute("interestRate", interestRate);
     model.addAttribute("months", months);
     model.addAttribute("emi", emi);
     
     return "calculator"; // calculator.jsp
 }
 
 private double calculateEMI(double principal, double interestRate, int months) {
     double monthlyRate = interestRate / (12 * 100);
     return (principal * monthlyRate * Math.pow(1 + monthlyRate, months)) / 
            (Math.pow(1 + monthlyRate, months) - 1);
 }
 
 private double calculatePrincipal(double emi, double interestRate, int months) {
     double monthlyRate = interestRate / (12 * 100);
     return emi * ((Math.pow(1 + monthlyRate, months) - 1) / 
            (monthlyRate * Math.pow(1 + monthlyRate, months)));
 }
 
 private double calculateInterestRate(double principal, double emi, int months) {
     // Need to use numerical methods to solve for interest rate
     // Using bisection method
     double low = 0.0;
     double high = 100.0;
     double tolerance = 0.0001;
     
     while ((high - low) > tolerance) {
         double mid = (low + high) / 2;
         double monthlyRate = mid / (12 * 100);
         double calculatedEmi = (principal * monthlyRate * Math.pow(1 + monthlyRate, months)) / 
                               (Math.pow(1 + monthlyRate, months) - 1);
         
         if (calculatedEmi < emi) {
             low = mid;
         } else {
             high = mid;
         }
     }
     
     return (low + high) / 2;
 }
 
 private int calculateMonths(double principal, double interestRate, double emi) {
     double monthlyRate = interestRate / (12 * 100);
     
     // Basic check to ensure EMI is greater than monthly interest
     if (emi <= principal * monthlyRate) {
         throw new IllegalArgumentException("EMI is too small to ever pay off the loan");
     }
     
     // Using logarithm to solve for months
     return (int) Math.ceil(Math.log(emi / (emi - principal * monthlyRate)) / 
                           Math.log(1 + monthlyRate));
 }
}