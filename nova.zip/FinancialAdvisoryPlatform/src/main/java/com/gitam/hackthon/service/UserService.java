package com.gitam.hackthon.service;

import com.gitam.hackthon.model.User;

public interface UserService {
	public String UserRegistration(User user);
	public User checkuserlogin(String email,String upwd );
}
