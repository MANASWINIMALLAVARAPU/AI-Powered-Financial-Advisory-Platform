package com.gitam.hackthon.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class LearningController {

	

@GetMapping("/learning")
public String learningPage() {
    return "learning";
}

@GetMapping("/beginner")
public String beginnerPage() {
    return "beginner.jsp";
}
@GetMapping("/intermediate")
public String intermediatePage() {
    return "intermediate.jsp";
}
@GetMapping("/advance")
public String advancePage() {
    return "advance.jsp";
}

 // Corresponds to addExpense.jsp
}

