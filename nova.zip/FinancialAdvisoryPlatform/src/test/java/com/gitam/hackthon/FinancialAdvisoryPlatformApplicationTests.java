package com.gitam.hackthon;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FinancialAdvisoryPlatformApplicationTests {

	@Test
	void contextLoads() {
	}

}
